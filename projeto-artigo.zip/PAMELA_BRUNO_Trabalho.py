#!/usr/bin/env python
# coding: utf-8

# # Trabalho - Classificação 
# 
# * Pâmela Rodrigues Venturini de Souza
# * Bruno Gigioli Tomazi

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')

def figura():
    tamanho = plt.figure(figsize = [12,10])
    estilo = sns.set(font_scale = 1.3, style = 'white')
    return tamanho, estilo

df = pd.read_csv('Global_Financial_Inclusion_2017.csv', sep = ";")
df.head()


# In[2]:


df.info()


# In[3]:


df.isnull().sum()


# In[4]:


figura()
sns.heatmap(df.isna())


# # PRÉ-PROCESSAMENTO

# In[5]:


df1 = df[['economy', 'regionwb', 'female', 'age', 'educ', 'inc_q', 'emp_in', 'account', 'account_fin', 'account_mob', 'fin2', 'fin7', 'saved', 'fin16', 'fin17a', 'fin17b', 'borrowed', 'fin19', 'fin20', 'fin21', 'fin24', 'fin26', 'fin28', 'fin30', 'fin48']]
df1.head()


# In[6]:


df1 = df1.loc[(df1['regionwb'] == 'Latin America & Caribbean (excluding high income)')]

df1


# In[7]:


df1.info()


# In[8]:


df1.isnull().sum()


# In[9]:


figura()
sns.heatmap(df1.isna());


# In[10]:


df1.describe()


# In[11]:


df1.isnull().sum().sum()


# ## Preencher valores faltantes com a mediana

# In[12]:


idade_mediana = df1.age.median()

df1.age.fillna(idade_mediana, inplace = True)
df1.isnull().sum()


# In[13]:


resp_mediana = df1.account_mob.median()

df1.account_mob.fillna(resp_mediana, inplace = True)
df1.isnull().sum()


# In[14]:


df1.isnull().sum().sum()


# In[15]:


df1


# In[16]:


figura()
sns.heatmap(df1.isna());


# In[17]:


fig, matriz = plt.subplots(nrows = 3, ncols = 2, figsize = (10,20))

sns.boxplot(data = df1, y = 'age', ax = matriz[0,0]);
sns.histplot(data = df1, y = 'age', ax = matriz[0,1]);

sns.boxplot(data = df1, y = 'educ', ax = matriz[1,0]);
sns.histplot(data = df1, y = 'educ', ax = matriz[1,1]);

sns.boxplot(data = df1, y = 'inc_q', ax = matriz[2,0]);
sns.histplot(data = df1, y = 'inc_q', ax = matriz[2,1]);


# In[18]:


figura()
sns.pairplot(data = df1.iloc[:,2:8])


# In[19]:


df1.describe()


# ## Binarização dos atributos
# 
# ####  0 = NÃO  e  1 = SIM

# In[20]:


#Dividir as idades e grupo 
idade = pd.get_dummies(pd.cut(x = df1.age, bins = [0, 18, 28, 60, 100], labels = ['adolescente', 'jovem', 'adulto', 'idoso'], right = False, include_lowest = True))
idade


# In[21]:


figura()
sns.barplot(data=idade, palette='Blues', estimator = sum, ci = None);


# In[22]:


educ = pd.get_dummies(df1.educ.replace({1:'ate_fund', 2:'ate_EM', 3:'acima_sup'}))[['ate_fund', 'ate_EM', 'acima_sup']]
educ


# In[23]:


figura()
sns.barplot(data=educ, palette='Blues', estimator = sum, ci = None);


# In[24]:


inc_q = pd.get_dummies(df1.inc_q.replace({1:'maispobre_20', 2:'segundo_20', 3:'medio_20', 4:'quarta_20', 5:'maisrico_20'}))[['maispobre_20', 'segundo_20', 'medio_20', 'quarta_20', 'maisrico_20']]
inc_q


# In[25]:


figura()
sns.barplot(data=inc_q, palette='Blues', estimator = sum, ci = None);


# In[26]:


df2 = pd.concat([df1.drop(['age', 'educ', 'inc_q'],axis = 1), idade, educ, inc_q], axis = 1)
df2


# In[27]:


#Colunas com o SIM no 0:
emp_in = pd.get_dummies(df1.emp_in.replace({0:'emp_in'}))[['emp_in']]
account = pd.get_dummies(df1.account.replace({0:'account'}))[['account']]
account_fin = pd.get_dummies(df1.account_fin.replace({0:'account_fin'}))[['account_fin']]
account_mob = pd.get_dummies(df1.account_mob.replace({0:'account_mob'}))[['account_mob']]
saved = pd.get_dummies(df1.saved.replace({0:'saved'}))[['saved']]
borrowed = pd.get_dummies(df1.borrowed.replace({0:'borrowed'}))[['borrowed']]

#Colunas com o SIM no 1:
female = pd.get_dummies(df1.emp_in.replace({1:'female'}))[['female']]
fin2 = pd.get_dummies(df1.account.replace({1:'fin2'}))[['fin2']]
fin7 = pd.get_dummies(df1.account_fin.replace({1:'fin7'}))[['fin7']]
fin16 = pd.get_dummies(df1.account_mob.replace({1:'fin16'}))[['fin16']]
fin17a = pd.get_dummies(df1.saved.replace({1:'fin17a'}))[['fin17a']]
fin17b = pd.get_dummies(df1.borrowed.replace({1:'fin17b'}))[['fin17b']]
fin19 = pd.get_dummies(df1.emp_in.replace({1:'fin19'}))[['fin19']]
fin20 = pd.get_dummies(df1.account.replace({1:'fin20'}))[['fin20']]
fin21 = pd.get_dummies(df1.account_fin.replace({1:'fin21'}))[['fin21']]
fin24 = pd.get_dummies(df1.account_mob.replace({1:'fin24'}))[['fin24']]
fin26 = pd.get_dummies(df1.saved.replace({1:'fin26'}))[['fin26']]
fin28 = pd.get_dummies(df1.borrowed.replace({1:'fin28'}))[['fin28']]
fin30 = pd.get_dummies(df1.saved.replace({1:'fin30'}))[['fin30']]
fin48 = pd.get_dummies(df1.borrowed.replace({1:'fin48'}))[['fin48']]


df2 = pd.concat([df2.drop(['female', 'emp_in', 'account', 'account_fin', 'account_mob', 'saved', 'borrowed', 'fin2', 'fin7', 'fin16', 'fin17a', 'fin17b', 'fin19', 'fin20', 'fin21', 'fin24', 'fin26', 'fin28', 'fin30', 'fin48'],axis = 1), female, emp_in, account, account_fin, account_mob, saved, borrowed, fin2, fin7, fin16, fin17a, fin17b, fin19, fin20, fin21, fin24, fin26, fin28, fin30, fin48], axis = 1)
df2


# ## Separar o DataFrame do Brasil dos demais países da América Latina

# In[28]:


df1.economy.value_counts()


# In[29]:


#Criando um DataFrame somente com os dados do BRASIL
df_brasil = df2.loc[(df2['economy'] == 'Brazil')]
df_brasil = pd.concat([df_brasil.drop(['economy', 'regionwb'],axis = 1)])

df_brasil


# In[30]:


df_brasil.describe()


# In[31]:


df_brasil.female.value_counts()


# In[32]:


#Criando um DataFrame com os dados dos países da AMÉRICA LATINA exceto o BRASIL
df_latina = df2.loc[(df2['economy'] != 'Brazil')]
df_latina = pd.concat([df_latina.drop(['economy', 'regionwb'],axis = 1)])

df_latina


# In[33]:


df_latina.describe()


# # MINERAÇÃO DE DADOS

# ## Correlação dos dados

# In[42]:


df_brasil.corr(method = 'kendall') 


# In[43]:


figura()
sns.heatmap(df_brasil.iloc[:,0:32].corr(method = 'kendall'), cmap = 'Blues');


# In[44]:


df_latina.corr(method = 'kendall')


# In[45]:


figura()
sns.heatmap(df_latina.iloc[:,0:32].corr(method = 'kendall'), cmap = 'Blues');


# # Classificação

# In[38]:


y_brasil = df_brasil.female
y_latina = df_latina.female


# In[39]:


x_brasil = df_brasil.drop(['female', 'fin19', 'emp_in'], axis = 1)
x_latina = df_latina.drop(['female', 'fin19', 'emp_in'], axis = 1)

#Notamos que o female possui um relação total com fin19 e inversa com o emp_in, 
# ou seja todas as mulher tem emprestimo e todas estão empregadas.


# In[46]:


from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2

# feature extraction
test = SelectKBest(chi2, k=10)
fit = test.fit(x_brasil, y_brasil)
features = fit.transform(x_brasil)

print(features)


# In[49]:


cols = fit.get_support(indices=True)
df_brasil.iloc[:,cols]


# In[50]:


from sklearn.ensemble import RandomForestClassifier

# feature extraction
model = RandomForestClassifier(n_estimators=10)
model.fit(x_brasil, y_brasil)
RandomForestClassifier(bootstrap=True, ccp_alpha=0.0, class_weight=None,
                       criterion='gini', max_depth=None, max_features='auto',
                       max_leaf_nodes=None, max_samples=None,
                       min_impurity_decrease=0.0, min_impurity_split=None,
                       min_samples_leaf=1, min_samples_split=2,
                       min_weight_fraction_leaf=0.0, n_estimators=10,
                       n_jobs=None, oob_score=False, random_state=None,
                       verbose=0, warm_start=False)


# In[51]:


print(model.feature_importances_)


# In[53]:


import pandas as pd
feature_importances = pd.DataFrame(model.feature_importances_,
                                   index = x_brasil.columns,
                                   columns=['importance']).sort_values('importance', ascending=False)
feature_importances


# In[54]:


# Visualizando as importâncias de forma gráfica:
feature_importances.plot(kind='bar')


# ## Árvore de Decisão

# In[55]:


from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import BernoulliNB
from sklearn.metrics import classification_report, confusion_matrix


DT = DecisionTreeClassifier(max_depth = 5)
DT.fit(x_brasil, y_brasil)


# In[56]:


DT_pred = DT.predict(x_latina)

print(DT_pred)

print(classification_report(y_latina, DT_pred))

print(confusion_matrix(y_latina, DT_pred))


# In[57]:


from sklearn.metrics import roc_auc_score, roc_curve
import matplotlib.pyplot as plt


# Estimando as probabilidades
AD_prob = DT.predict_proba(x_brasil)
probs = AD_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='AD',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# In[61]:


DT = DecisionTreeClassifier(max_depth = 5, min_samples_leaf = 20)
DT.fit(x_brasil, y_brasil)

DT_pred = DT.predict(x_latina)
print(DT_pred)

print(classification_report(y_latina, DT_pred))

print(confusion_matrix(y_latina, DT_pred))


# In[62]:


# Estimando as probabilidades
AD_prob = DT.predict_proba(x_brasil)
probs = AD_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='AD - S=20',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# In[63]:


DT = DecisionTreeClassifier(max_depth = 5, min_samples_leaf = 50)
DT.fit(x_brasil, y_brasil)

DT_pred = DT.predict(x_latina)
print(DT_pred)

print(classification_report(y_latina, DT_pred))

print(confusion_matrix(y_latina, DT_pred))


# In[64]:


# Estimando as probabilidades
AD_prob = DT.predict_proba(x_brasil)
probs = AD_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='AD - S=50',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# In[65]:


DT = DecisionTreeClassifier(max_depth = 5, min_samples_leaf = 150)
DT.fit(x_brasil, y_brasil)

DT_pred = DT.predict(x_latina)
print(DT_pred)

print(classification_report(y_latina, DT_pred))

print(confusion_matrix(y_latina, DT_pred))


# In[66]:


# Estimando as probabilidades
AD_prob = DT.predict_proba(x_brasil)
probs = AD_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='AD - S=150',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# In[67]:


DT = DecisionTreeClassifier(max_depth = 5, min_samples_leaf = 300)
DT.fit(x_brasil, y_brasil)

DT_pred = DT.predict(x_latina)
print(DT_pred)

print(classification_report(y_latina, DT_pred))

print(confusion_matrix(y_latina, DT_pred))


# In[68]:


# Estimando as probabilidades
AD_prob = DT.predict_proba(x_brasil)
probs = AD_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='AD - S=300',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# ## K-vizinho Mais Próximo

# In[69]:


KNN = KNeighborsClassifier() 

KNN.fit(x_brasil, y_brasil)
KNN_pred = KNN.predict(x_latina)

print(KNN_pred)

print(classification_report(y_latina, KNN_pred))

print(confusion_matrix(y_latina, KNN_pred))


# In[70]:


# Estimando as probabilidades
KNN_prob = KNN.predict_proba(x_brasil)
probs = KNN_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='KNN',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# In[71]:


KNN = KNeighborsClassifier(n_neighbors = 1) 

KNN.fit(x_brasil, y_brasil)
KNN_pred = KNN.predict(x_latina)

print(KNN_pred)

print(classification_report(y_latina, KNN_pred))

print(confusion_matrix(y_latina, KNN_pred))


# In[72]:


# Estimando as probabilidades
KNN_prob = KNN.predict_proba(x_brasil)
probs = KNN_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='KNN - K=1',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# In[73]:


KNN = KNeighborsClassifier(n_neighbors = 3) 

KNN.fit(x_brasil, y_brasil)
KNN_pred = KNN.predict(x_latina)

print(KNN_pred)

print(classification_report(y_latina, KNN_pred))

print(confusion_matrix(y_latina, KNN_pred))


# In[74]:


# Estimando as probabilidades
KNN_prob = KNN.predict_proba(x_brasil)
probs = KNN_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='KNN - K=3',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# In[75]:


KNN = KNeighborsClassifier(n_neighbors = 5) 

KNN.fit(x_brasil, y_brasil)
KNN_pred = KNN.predict(x_latina)

print(KNN_pred)

print(classification_report(y_latina, KNN_pred))

print(confusion_matrix(y_latina, KNN_pred))


# In[76]:


# Estimando as probabilidades
KNN_prob = KNN.predict_proba(x_brasil)
probs = KNN_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='KNN - K=5',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# In[77]:


KNN = KNeighborsClassifier(n_neighbors = 15) 

KNN.fit(x_brasil, y_brasil)
KNN_pred = KNN.predict(x_latina)

print(KNN_pred)

print(classification_report(y_latina, KNN_pred))

print(confusion_matrix(y_latina, KNN_pred))


# In[78]:


# Estimando as probabilidades
KNN_prob = KNN.predict_proba(x_brasil)
probs = KNN_prob[:, 1]
rfp, rvp, lim = roc_curve(y_brasil, probs)

# Gráfico da curva roc
plt.plot(rfp, rvp, marker='.', label='KNN - K=15',color="purple")
plt.plot([0, 1], [0, 1], color='darkblue', linestyle='--')

# Nome dos eixos
plt.ylabel('Sensibilidade')

plt.legend()
plt.show()

auc = roc_auc_score(y_brasil, probs)
print("AUC: ", auc)


# ## Naïve Bayes - Bernoulli

# In[79]:


from sklearn.preprocessing import KBinsDiscretizer

disc = KBinsDiscretizer(n_bins=2, strategy='kmeans')


# In[80]:


disc.fit(x_brasil)
x_brasil_disc = disc.transform(x_brasil)
x_latina_disc = disc.transform(x_latina)


# In[81]:


np.shape(x_latina_disc)


# In[82]:


x_latina_disc


# In[83]:


print(x_latina_disc)


# In[84]:


NB = BernoulliNB()

NB.fit(x_brasil_disc, y_brasil)
NB_pred = NB.predict(x_latina_disc)

NB_pred


# In[85]:


print(classification_report(y_latina, NB_pred))


# In[86]:


print(confusion_matrix(y_latina, NB_pred))


# In[ ]:




